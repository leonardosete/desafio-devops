class Config(object):
    DEBUG = True


class TestConfig(Config):
    DEBUG = True
    TESTING = True
